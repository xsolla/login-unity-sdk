#Firebase deployment

You need to create Firebase project https://firebase.google.com/

1. Install nodejs https://nodejs.org/en/download/
2. $ npm install -g firebase-tools
3. $ firebase login
4. Check and set if necessary your project name in .firebaserc
5. $ cd functions
6. $ npm install
7. $ npm run deploy